package a25.climoilou.web2.TP2_Rose_Zara;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tp2RoseZaraApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tp2RoseZaraApplication.class, args);
	}

}
