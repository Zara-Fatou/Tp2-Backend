package a25.climoilou.web2.TP2_Rose_Zara;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp2RoseZaraApplicationTests {

	@Test
	void contextLoads() {
	}

}
